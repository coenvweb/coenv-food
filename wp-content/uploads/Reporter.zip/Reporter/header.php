<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :'; } ?> <?php bloginfo('name'); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/sidebar.css" media="screen" />	

<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />


<?php 
wp_enqueue_script('jquery');
wp_enqueue_script('superfish', get_stylesheet_directory_uri() .'/js/superfish.js');
wp_enqueue_script('jqui', get_stylesheet_directory_uri() .'/js/jquery-ui-personalized-1.5.2.packed.js');
wp_enqueue_script('slides', get_stylesheet_directory_uri() .'/js/slides.min.jquery.js');
wp_enqueue_script('effects', get_stylesheet_directory_uri() .'/js/effects.js');
wp_enqueue_script('liscroll', get_stylesheet_directory_uri() .'/js/liscroll.js');
?>

<?php wp_get_archives('type=monthly&format=link'); ?>
<?php //comments_popup_script(); // off by default ?>

<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); wp_head(); ?>

</head>
<body>
<div id="topribbon">
<div id="wrapper">  <!-- wrapper begin -->
<div id="masthead"><!-- masthead begin -->

	<div id="top"> 
			
		<div class="date-stamp">
			<span class="day"><?php echo date('j '); ?></span>
			<span class="mony"><?php echo date(' M  '); ?></span>
			<span class="dname"><?php echo date(' Y '); ?></span>
		</div>
		
		<h1 class="logo"><a href="<?php bloginfo('siteurl');?>/" title="<?php bloginfo('name');?>"><?php bloginfo('name');?></a></h1>
			
		<div class="topfeed">
			<ul>
				<li><a href="<?php bloginfo('rss2_url'); ?>" >Articles</a></li>
				<li><a href="<?php bloginfo('rss2_url'); ?>" >Responses</a></li>
			</ul>
		</div>
		
	</div>
	
	<div id="botmenu">
		<?php wp_nav_menu( array( 'container_id' => 'submenu', 'theme_location' => 'primary','menu_class'=>'sfmenu','fallback_cb'=> 'fallbackmenu' ) ); ?>
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>	
	</div>
	
</div><!--end masthead-->

<div class="scrollposts">

<?php 
$tick_cat = get_option('repo_tick_cat');
$ticker_query = new WP_Query( 'category_name='.$tick_cat.'&posts_per_page=5' );
// The Loop
echo '<ul id="ticker">';
while( $ticker_query->have_posts() ) : $ticker_query->the_post();

	echo '<li>';
	echo '<span>';
	the_time('M : j : Y'); 
	echo '</span>';
	echo ' - ';
	the_title();
	echo '</li>';
endwhile;
	echo '</ul>';
wp_reset_postdata(); ?>

</div>

<div id="casing">