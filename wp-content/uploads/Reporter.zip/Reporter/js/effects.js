jQuery(document).ready(function() {

/* Navigation */
jQuery('#submenu ul.sfmenu').superfish({ 
		delay:       500,								// 0.1 second delay on mouseout 
		animation:   {opacity:'show',height:'show'},	// fade-in and slide-down animation 
		dropShadows: true								// disable drop shadows 
	});	

jQuery("ul#ticker").liScroll({travelocity: 0.1});

jQuery('#slides').slides({
				
				play: 5000,
				crossfade: true,
				pause: 2500,
				hoverPause: true,
				animationStart: function(current){
					jQuery('.caption').animate({
						bottom:-35
					},100);
					if (window.console && console.log) {
						// example return of current slide number
						console.log('animationStart on slide: ', current);
					};
				},
				animationComplete: function(current){
					jQuery('.caption').animate({
						bottom:0
					},200);
					if (window.console && console.log) {
						// example return of current slide number
						console.log('animationComplete on slide: ', current);
					};
				},
				slidesLoaded: function() {
					jQuery('.caption').animate({
						bottom:0
					},200);
				}
			}); 
			
jQuery('#newtabs> ul').tabs({ fx: {  opacity: 'toggle' } }); 			
	
});
