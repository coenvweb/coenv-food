<?php get_header(); ?>


<div id="content">

<?php include (TEMPLATEPATH . '/slide.php'); ?>	

<div class="high-box lbox"> <!-- #################  highlight category-1 #################### -->
<?php $high_cat1 = get_option('repo_high_cat1'); ?>
<h2 class="high-cat"><?php echo $high_cat1  ?>

</h2>
<?php $i = 1;?>
<?php
$high_cat1 = get_option('repo_high_cat1');
$high_query = new WP_Query( 'category_name='.$high_cat1.'&posts_per_page=4' );
while ( $high_query->have_posts() ) : $high_query->the_post();
?>
<?php if($i == 1):?>

<div class="high-first-item">
<img class="highmage" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php get_image_url(); ?>&amp;h=100&amp;w=310&amp;zc=1" alt="" />
<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h3>
	<?php wpe_excerpt('wpe_excerptlength_slide', 'wpe_excerptmore'); ?>
</div>

<?php elseif($i > 1 ):?>

<div class="high-rest-item">
<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php echo short_title('...', 5); ?></a></h3>
</div>
 <?php endif; ?>

 <?php $i++; ?>
<?php endwhile; ?>

</div>


<div class="high-box rbox"> <!-- #################  highlight category-2 #################### -->
<?php $high_cat2 = get_option('repo_high_cat2'); ?>
<h2 class="high-cat"><?php echo $high_cat2 ?></h2>
<?php $i = 1;?>
<?php
$high_cat2 = get_option('repo_high_cat2');
$high_query = new WP_Query( 'category_name='.$high_cat2.'&posts_per_page=4' );
while ( $high_query->have_posts() ) : $high_query->the_post();
?>
<?php if($i == 1):?>

<div class="high-first-item">
<img class="highmage" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php get_image_url(); ?>&amp;h=100&amp;w=310&amp;zc=1" alt="" />
<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h3>
	<?php wpe_excerpt('wpe_excerptlength_slide', 'wpe_excerptmore'); ?>
</div>

<?php elseif($i > 1 ):?>

<div class="high-rest-item">
<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php echo short_title('...', 5); ?></a></h3>
</div>
 <?php endif; ?>

 <?php $i++; ?>
<?php endwhile; ?>

</div>

<div class="clear"></div>

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<div class="post" id="post-<?php the_ID(); ?>">

<div class="title">
	<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
</div>
<div class="postmeta">
	<span class="author">Posted by <?php the_author(); ?> </span> <span class="clock">  <?php the_time('M - j - Y'); ?></span> <span class="comm"><?php comments_popup_link('0 Comment', '1 Comment', '% Comments'); ?></span>
</div>

<div class="entry">


<?php
if ( has_post_thumbnail() ) { ?>
	<a href="<?php the_permalink() ?>"><img class="postimg" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php get_image_url(); ?>&amp;h=150&amp;w=200&amp;zc=1" alt=""/></a>
<?php } else { ?>
	<a href="<?php the_permalink() ?>"><img class="postimg" src="<?php bloginfo('template_directory'); ?>/images/dummy.png" alt="" /></a>
<?php } ?>

<?php wpe_excerpt('wpe_excerptlength_index', ''); ?>

<div class="clear"></div>

</div>

</div>

<?php endwhile; ?>

<div class="clear"></div>

<?php getpagenavi(); ?>

<?php else : ?>
		<h1 class="title">Not Found</h1>
		<p>Sorry, but you are looking for something that isn't here.</p>
<?php endif; ?>
      <?php wp_reset_query(); ?>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>