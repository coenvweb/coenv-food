<div id="slides">
<h2 class="left-title">Featured articles</h2>
<div class="slides_container">
<?php
$slide = get_option('repo_slide_cat');
$count = get_option('repo_slide_count');
$slide_query = new WP_Query( 'category_name='.$slide.'&posts_per_page='.$count.'' );
while ( $slide_query->have_posts() ) : $slide_query->the_post();
?>

<div class="slide">
<?php
if ( has_post_thumbnail() ) { ?>
	<a href="<?php the_permalink() ?>"><img class="slidimg" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php get_image_url(); ?>&amp;h=250&amp;w=655&amp;zc=1" alt=""/></a>
<?php } else { ?>
	<a href="<?php the_permalink() ?>"><img class="slidimg" src="<?php bloginfo('template_directory'); ?>/images/dummy.png" alt="" /></a>
<?php } ?>
	<div class="caption" style="bottom:0">
		<?php wpe_excerpt('wpe_excerptlength_slide', ''); ?>
	</div>
</div>

<?php endwhile; ?>
</div>

</div>