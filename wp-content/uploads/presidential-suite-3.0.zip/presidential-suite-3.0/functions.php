<?php
if ( function_exists('register_sidebars') )
    register_sidebars(2);
    
add_filter( 'wp_feed_cache_transient_lifetime', create_function('$a', 'return 60;') );
    
?>