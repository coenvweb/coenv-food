
          <div id="leftNav" class="span-6">
          	<div class="leftNavBackground">
          		
         	<?php wp_page_menu('title_li=&sort_column=menu_order&show_home=1') ?>
          
              <br class="clear" /><br class="clear" />
          	</div>
          </div>
          
          
