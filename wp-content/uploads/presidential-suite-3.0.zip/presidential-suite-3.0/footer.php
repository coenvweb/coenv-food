<!-- begin footer -->

</div>	   <br class="clear" /></div>   
          <div id="bottomRoundedLeft"></div> 
  </div>
 
  </div>
</div>

<div id="footerMain">
  <div id="footerLeft">    	
		<ul>
   		  <li class="centerText"><a href="http://www.washington.edu/">&#169; <?php echo date('Y'); ?> UNIVERSITY OF WASHINGTON</a></li>  
        </ul>
  </div>    
    <div id="footerRight">  
    	 <ul>  	
  		   <li class="centerText"><a href="http://www.seattle.gov/">SEATTLE, WASHINGTON</a></li>
         </ul>   
  </div>    
  	<div id="footerCenter">
        <ul>
          <li><a href="http://www.washington.edu/home/siteinfo/form">Contact Us</a></li>
          <li class="footerLinkBorder"><a href="http://www.washington.edu/jobs">Jobs</a></li>
          <li class="footerLinkBorder"><a href="http://myuw.washington.edu/">My UW</a></li>
          <li class="footerLinkBorder"><a href="http://www.washington.edu/admin/rules/wac/rulesindex.html">Rules Docket</a></li>
          <li class="footerLinkBorder"><a href="http://www.washington.edu/online/privacy">Privacy</a></li>
          <li class="footerLinkBorder"><a href="http://www.washington.edu/online/terms">Terms</a></li>
        </ul>
  	</div>
</div>    

</body>
</html>