<?php get_header(); ?>

<?php include(TEMPLATEPATH."/l_sidebar.php");?>

<div id="region-content" class="span-18 last">
  <div id="informationStory" class="span-11 append-1">
  
    <div class="contenttitle">
        <h1>Not Found, Error 404</h1><br />
        <p>The page you are looking for no longer exists.</p>		
    </div>
        

</div>
	
<?php include(TEMPLATEPATH."/r_sidebar.php");?>



<!-- The main column ends  -->

<?php get_footer(); ?>
