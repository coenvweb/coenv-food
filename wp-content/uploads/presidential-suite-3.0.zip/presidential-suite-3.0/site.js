function initMenu() {
$('.menu > ul').attr("id", 'menu');
  $('#menu ul').hide();
  $('#menu li:first').addClass('selectedAccordion');
  $('#menu li:first').addClass('navSectionHead');

  var array = location.href.split('/');
  array = array[array.length-2].replace(/-/g,' ');
  
  $('a').each(function() {	   
	if($(this).text().toLowerCase() == array.toLowerCase()) {
		$(this).parent().parent('ul').show();
		$(this).parents(':eq(2)').find('a:first').addClass('selectedAccordion');
		$(this).addClass('selectedLink');
	}
  });	
	
  if($("#menu > li > ul")) {
	$("#menu > li > ul").each(function() {
		$(this).parent('li').addClass('selectedArrow');
	});
}
  $('#menu li a').click(
    function() {
      $('#menu li a').removeClass('selectedAccordion');
  	  $(this).addClass('selectedAccordion');
  	  $('#menu ul.currentnav li a').removeClass('selectedAccordion');
  	  $('#menu li ul li a').removeClass('selectedAccordion');
  	  //$(this).parent('li').addClass('selectedAccordion');
      var checkElement = $(this).next();
      if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
        return false;
        }
      if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
        $('#menu ul:visible').slideUp('normal');
        checkElement.slideDown('normal');
        return false;
        }
      }
    );
  }
$(document).ready(function() {initMenu();});

/* --------- Search box clear --------- */

$(document).ready(function () {
	$(".wTextInput").focus(function () {
		if ($(this).val() === $(this).attr("title")) {
			$(this).val("");
		}
	}).blur(function () {
		if ($(this).val() === "") {
			$(this).val($(this).attr("title"));
		}
	});
});
